package com.todo.taskgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskgeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskgeneratorApplication.class, args);
	}

}
