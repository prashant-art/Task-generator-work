package com.todo.taskgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskgeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
